package at.rpisec.test.oauth.logic;

/**
 * @author Thomas Herzog <herzog.thomas81@gmail.com>
 * @since 05/12/17
 */
public class Dummy {
}
