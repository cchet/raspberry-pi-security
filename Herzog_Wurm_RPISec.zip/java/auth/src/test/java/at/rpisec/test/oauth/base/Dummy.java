package at.rpisec.test.oauth.base;

/**
 * https://docs.spring.io/spring/docs/current/spring-framework-reference/html/integration-testing.html
 *
 * @author Thomas Herzog <herzog.thomas81@gmail.com>
 * @since 05/12/17
 */
public class Dummy {
}
