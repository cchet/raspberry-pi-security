package at.rpisec.sensor.api.listener;

/**
 * @author Philipp Wurm <philipp.wurm@gmail.com>.
 */
public interface IncidentEvent {
}
